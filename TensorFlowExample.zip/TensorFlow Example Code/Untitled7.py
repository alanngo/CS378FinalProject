
# coding: utf-8

# In[1]:


get_ipython().system('pip install -q h5py pyyaml')


# In[ ]:


from __future__ import absolute_import, division, print_function 

import os

import tensorflow as tf
from tensorflow import keras

tf.__version__

(train_images, train_labels), (test_images, test_labels) = tf.keras.datasets.mnist.load_data()

train_labels = train_labels[:1000]
test_labels = test_labels[:1000]

train_images = train_images[:1000].reshape

